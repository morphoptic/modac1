Examples
========

This directory contains examples on using pynng for different tasks.

* [`pair0.py`](./pair0.py): Demonstrates the basic bi-directional connection,
  pair0.  Adapted from [nng pair
  example](https://nanomsg.org/gettingstarted/nng/pair.html).
* [`pair1_async.py`](./pair1_async.py): Demonstrates a polyamorous pair1
  connection.

Adding an Example
-----------------

More examples are welcome.  To add an example:
1. create a new file in this directory that demonstrates what needs to be
   demonstrated
2. Make sure there is a docstring in the file that describes what it is
   demonstrating.  Add as much detail as is needed.  Show example in the
   docstring as well.
3. Add a short description of what the example does to the list of descriptions
   in this file.  Keep the list in alphabetical order.

Don't call out to third-party code if you can help it.  Keep examples simple.
If you are adding an async example, use
[trio](https://trio.readthedocs.io/en/latest/).
